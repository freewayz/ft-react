from django.apps import AppConfig


class AssigmentConfig(AppConfig):
    name = 'assigment'
